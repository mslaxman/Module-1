package com;

import java.util.Scanner;
/**
 * 
 * @author Laxman
 *
 */
public class E1 {
	public int getCube(int n) {
		int cube=0;
		while(n>0) {
			int p=n%10;
			cube+=(p*p*p);
			n=n/10;	
		}
		return cube;
	}
	public static void main(String s[]) {
		E1 l=new E1();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		System.out.println(l.getCube(n));
		sc.close();
	}

}
