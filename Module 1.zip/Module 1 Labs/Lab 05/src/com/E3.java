package com;

import java.util.Scanner;

/**
 * 
 * @author Laxman
 *
 */

public class E3 {
	public void getPrime(int n){
		for(int i=2;i<=n;i++) {
			int count=0;
		    for(int j=2;j<i;j++) {
			   if(i%j==0) {
				  count++;
				  break;	
			   }
		    }
			if(count==0) {
              System.out.println(i);
		}
	}		
		
	}
	public static void main(String args[]) {
		E3 e=new E3();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		sc.close();
		e.getPrime(n);
		
	}

}
