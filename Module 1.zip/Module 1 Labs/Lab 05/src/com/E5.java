package com;

import java.util.Scanner;

/**
 * 
 * @author Laxman
 *
 */

class AgeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AgeException(String s) {
		super(s);
	}
}

public class E5 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		sc.close();
		try {
			if(age<=15)
				throw new AgeException("Fine");
			else
				System.out.println("Age : "+age);
		}catch(AgeException e) {
			System.out.println("Age of a person should be above 15.");
		}
	}

}
