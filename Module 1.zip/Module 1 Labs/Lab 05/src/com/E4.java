package com;

import java.util.Scanner;

/**
 * 
 * @author Laxman
 *
 */
public class E4 {
	public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter First Name");
	String fn=sc.nextLine();
	System.out.println("Enter Last Name");
	String ln=sc.nextLine();
	sc.close();
	try {
		if(ln.isEmpty() || fn.isEmpty()) {
			throw new NullPointerException();
		   }
		else
			System.out.println(fn+" "+ln);
	}catch(NullPointerException e) {
		System.out.println("Name field should not be empty");
	}
	
  }
}
