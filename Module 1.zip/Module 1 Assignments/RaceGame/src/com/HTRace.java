package com;

/**
 * 
 * @author Laxman
 *
 */
public class HTRace implements Runnable {
	int count;
	public void run()
	{
		try
		{
			for(int i=0;i<100;i++)
			{			
				while(i>=0)
				{
					count++;
					System.out.println(Thread.currentThread().getName()+" has reached "+i+" meters");
					if(count == 60)
					{
						if(Thread.currentThread().getName().contentEquals("t1"))
						{
							Thread.sleep(1000);
						}
					}
					if(count==100)
					{
						System.err.println(Thread.currentThread().getName()+"has won the race");
						System.exit(0);
					}
					break;
				}
			}
		}
		catch (Exception e) {
			e.getLocalizedMessage();
		}
	}
	public static void main(String[] args) {
		HTRace race = new HTRace();
		Thread t1 = new Thread(race, "Hare");
		Thread t2 = new Thread(race, "Tortoise");
		t1.setPriority(8);
		t2.setPriority(6);
		t1.start();
		t2.start();
	}

}
