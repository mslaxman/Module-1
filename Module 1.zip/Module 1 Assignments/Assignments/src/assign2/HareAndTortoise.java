package assign2;


public class HareAndTortoise implements Runnable {
	/**
	 * @author Ansh
	 */
	int count;
	public void run()
	{
		try
		{
			//Thread.sleep(1000);
		
		for(int i=0;i<100;i++)
		{
			
			
			
			while(i>=0)
			{
				count++;
				System.out.println(Thread.currentThread().getName()+"has reached"+i+"meters");
				if(count == 60)
				{
					if(Thread.currentThread().getName().contentEquals("hare"))
					{
						Thread.sleep(1000);
					}
				}
				if(count==100)
				{
					System.err.println(Thread.currentThread().getName()+"has win the race");
					//Thread.sleep(1000);
					System.exit(0);
				}
				break;
			}
			
			
		}
		}
		catch (Exception e) {
			e.getLocalizedMessage();
		}
		
		
	}

	public static void main(String[] args) {
		HareAndTortoise hat = new HareAndTortoise();
		Thread hare = new Thread(hat, "hare");
		Thread tortoise = new Thread(hat, "tortoise ");
		hare.setPriority(8);
		tortoise.setPriority(6);
		hare.start();
		tortoise.start();
		

	}

}
