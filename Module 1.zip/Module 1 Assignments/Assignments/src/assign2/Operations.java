package assign2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Operations {
	/**
	 * @author Ansh
	 * @param ags
	 */
	public static void main(String[] ags)
	{
		List<String> li = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
		do
		{
		System.out.println("Enter your option:");
		System.out.println("1.Insert");
		System.out.println("2.Search");
		System.out.println("3.Delete");
		System.out.println("4.Display");
		System.out.println("5.Exit");
		int choice = sc.nextInt();
		
		switch(choice)
		{
		case 1:
			System.err.println("Enter the element to be inserted:");
			String ins =sc.next();
			li.add(ins);
			System.err.println(li);
			System.err.println("Element inserted.");
			break;
		case 2:
			System.err.println("Enter element to search:");
			String search = sc.next();
			if(li.contains(search))
			{
				System.err.println("Element found.");
			}
			else
			{
				System.err.println("Element does not exist");
			}
			break;
		case 3:
			System.err.println("Enter element to be deleted:");
			String delete = sc.next();
			if(li.contains(delete))
			{
				li.remove(delete);
			}
			else
			{
				System.err.println("Elements does not exist.");
			}
			break;
		case 4:
			System.err.println("Elements in the list are:"+li);
			break;
		case 5:
			System.err.println("Thanks for using!!!!!");
			System.exit(0);
			
		}
		}while(true);
		
		
	}

}
