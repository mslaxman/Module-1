package assign2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

class Card
{
	String card;
	Integer num;
	public Card()
	{
		
	}
	public String getCard() {
		return card;
	}
	public Card(String card, Integer num) {
		super();
		this.card = card;
		this.num = num;
	}
	public Integer getNum() {
		return num;
	}
	public int hashCode()
	{
		return 1;
	}
	public boolean equals(Object obj)
	{
		//System.out.println("===========");
		if(obj instanceof Card && this.card.equals(((Card)obj).card))
		//if(this.getCard().equals((Card)obj.getCard())
		{
			//System.out.println("**********");
			return true;
		}
		else
		{
			return false;
		}
		
	}
	public String toString()
	{
		return "\t"+card+"\t"+num;
	}
	
}

public class CardDetails {
	/**
	 * @author Ansh
	 * @param args
	 */

	public static void main(String[] args) {
		String card;
		int num;
		Set<Card> hset = new HashSet<Card>();
		do
		{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a card and its number:");
		card = sc.next();
		num = sc.nextInt();
		hset.add(new Card(card,num));
		if(hset.size()==4)
		{
			System.out.println(hset);
		}
		}while(true);

	}

}
