package assign2;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

class Box 
{
	/**
	 * @author Ansh
	 */
	Integer length,width,height,volume;
	public Box()
	{
		
	}
	

	public Box(Integer length, Integer width, Integer height,Integer volume) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
		this.volume = volume;
	}

	public Integer getVolume() {
		return volume;
	}
	public Integer getLength() {
		return length;
	}

	public Integer getWidth() {
		return width;
	}

	public Integer getHeight() {
		return height;
	}


	@Override
	public boolean equals(Object obj) {
		
		return this.volume.equals(((Box)obj).volume);
	}


	@Override
	public int hashCode() {
		
		return 1;
	}


	@Override
	public String toString() {
		return "Box [length=" + length + ", width=" + width + ", height=" + height + ",volume="+ volume +"]";
	}


	


	
	
}

public class BoxVolume {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Set<Box> set = new HashSet<Box>();
		
		System.out.println("Enter the number of box:");
		int numBox = sc.nextInt();
		
			
			for(int i=1;i<=numBox;i++)
			{
				System.out.println("Enter details of box"+i);
				System.out.println("Enter length:");
				int len = sc.nextInt();
				System.out.println("Enter width:");
				int wid = sc.nextInt();
				System.out.println("Enter height:");
				int hig = sc.nextInt();
				int vol = len*wid*hig;
				set.add(new Box(len, wid, hig,vol));
				
				
				//Box box = new Box(len, wid, hig);
			
			}
			sc.close();
		for(Box j:set) {
			System.out.println(j);
		}
		

	}

	
}
