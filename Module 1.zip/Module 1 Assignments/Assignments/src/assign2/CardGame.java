package assign2;

import java.util.Map;
import java.util.Scanner;



public class CardGame {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of card:");
		int ncards = sc.nextInt();
		for(int i=0;i<ncards;i++)
		{
			Map<String,Integer> m = new Map<String, Integer>();
			
		}

	}

}
