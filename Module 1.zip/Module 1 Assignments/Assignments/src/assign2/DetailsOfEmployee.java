package assign2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
class Employee
{
	String fname, lname,address;
	long mob;
	public Employee(String fname, String lname,  long mob,String address) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.address = address;
		this.mob = mob;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getMob() {
		return mob;
	}
	public void setMob(long mob) {
		this.mob = mob;
	}
	
}
class SortByName implements Comparator<Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		
		return (o1.fname.compareTo(o2.fname));
	}
	
}

public class DetailsOfEmployee {
	/**
	 * @author Ansh
	 * @param args
	 */

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.err.println("Enter the nuber of employees");
		int empnum = sc.nextInt();
		DetailsOfEmployee doe = new DetailsOfEmployee();
		List<Employee> li = new ArrayList<Employee>();
		for(int i=1;i<=empnum;i++)
		{
			System.err.println("Enter first name of employee"+i);
			String firstName = sc.next();
			System.out.println("Enter last name of employee"+i);
			String lastName = sc.next();
			System.err.println("Enter mobile number:");
			long mobile = sc.nextInt();
			System.out.println("Enter address of employee");
			String address = sc.next();
			li.add(new Employee(firstName,lastName,mobile,address));
			
			//System.err.println("\t"+firstName+"\t"+lastName+"\t"+mobile);
		}
		//Collections.sort(li, (Employee a,Employee b)->a.getFname().compareTo(b.getFname()));
		Collections.sort(li,new SortByName() );
		
		for(Employee s : li)
		{
			//System.out.format("\tFirstname","\tLastname","\tAddress","\tMobile"); 
			System.err.println("\t"+s.getFname()+"\t"+s.getLname()+"\t"+s.getAddress()+"\t"+s.getMob());
			
		}
		

	}

}
