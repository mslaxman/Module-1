package com;

import java.util.Scanner;

abstract class Account
{
	double intrestRate,amount;
	abstract double calculateIntrest();
}
class FDAccount extends Account
{
	int noOfDays;
	//double intrestRate,amount;
	public void FDAccount()
	{
	int ageOfACHolder;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the FD amount:");
	amount=sc.nextDouble();
	
	System.out.println("Enter the number of days:");
	noOfDays=sc.nextInt();
	
	System.out.println("Enter your age:");
	ageOfACHolder = sc.nextInt();
	

	if(amount <= 1000000)
	{
		if(ageOfACHolder < 45)
		{
			if(noOfDays >= 7 && noOfDays <= 14)
			{
				intrestRate = 4.5;
				
			}
			else if(noOfDays >= 15 && noOfDays <= 29)
			{
				intrestRate = 4.75;
				
			}
			else if(noOfDays >= 30 && noOfDays <= 44)
			{
				intrestRate = 5.5;
				
			}
			else if(noOfDays >= 45 && noOfDays <= 60)
			{
				intrestRate = 7.00;
				
			}
			else if(noOfDays >= 61 && noOfDays <= 184)
			{
				intrestRate = 7.5;
				
			}
			else if(noOfDays >= 185 && noOfDays <= 365)
			{
				intrestRate = 8.00;
				
			}
			
		}
		else
		{
			if(noOfDays >= 7 && noOfDays <= 14)
			{
				
				intrestRate = 5.00;
			}
			else if(noOfDays >= 15 && noOfDays <= 29)
			{
				
				intrestRate = 5.25;
			}
			else if(noOfDays >= 30 && noOfDays <= 44)
			{
				
				intrestRate = 6.00;
			}
			else if(noOfDays >= 45 && noOfDays <= 60)
			{
				
				intrestRate = 7.5;
			}
			else if(noOfDays >= 61 && noOfDays <= 184)
			{
				
				intrestRate = 8.00;
			}
			else if(noOfDays >= 185 && noOfDays <= 365)
			{
				
				intrestRate = 8.5;
			}
		}
			

	}
	else
	{
		if(noOfDays >= 7 && noOfDays <= 14)
		{
			intrestRate = 6.5;
		}
		else if(noOfDays >= 15 && noOfDays <= 29)
		{
			intrestRate = 6.75;
		}
		else if(noOfDays >= 30 && noOfDays <= 44)
		{
			intrestRate = 6.75;
		}
		else if(noOfDays >= 45 && noOfDays <= 60)
		{
			intrestRate = 8;
		}
		else if(noOfDays >= 61 && noOfDays <= 184)
		{
			intrestRate = 8.5;
		}
		else if(noOfDays >= 185 && noOfDays <= 365)
		{
			intrestRate = 10.00;
		}
		else
		{
			System.out.println("wrong!!!!!");
		}
	}
}
	double calculateIntrest() {
		double res = (amount*intrestRate*noOfDays)/100;
		return res;
	}
	
}

public class BankIntrest {
	
	public static void main() {
		
		FDAccount fd = new FDAccount();
	}

}
