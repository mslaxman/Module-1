package bean;
/**
 * @author Laxman
 */
public class Box {

	int length;
	int width;
	int height;
	Integer volume;
	public Box(int length, int width, int height) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
		this.volume=length*width*height;
	}
	public int getLength() {
		return length;
	}
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return height;
	}
	public int hashCode() {
		return 1;
	}
	@Override
	public boolean equals(Object obj) {
		
		if(this.volume.equals(((Box)obj).volume)){
			return true;
		}
		else
			return false;
	}
	public String toString() {
		return "Length ="+length+" Width = "+width+" Height = "+height+" Volume = "+volume;
	}
	
}
