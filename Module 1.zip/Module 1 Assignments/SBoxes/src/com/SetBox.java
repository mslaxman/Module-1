package com;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import bean.Box;
/**
 * @author Laxman
 */
public class SetBox {

	public static void main(String[] args) {
		Set<Box> s=new HashSet<Box>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of boxes: ");
		int n=sc.nextInt();
		int i=1;
		while(n>0) {
			System.out.println("Enter the box "+i+" details:");
			System.out.println("Enter Length: ");
			int l=sc.nextInt();
			System.out.println("Enter Width: ");
			int w=sc.nextInt();
			System.out.println("Enter Height: ");
			int h=sc.nextInt();
			s.add(new Box(l,w,h));
			n--;
			i++;
		}
		System.out.println("Unique Boxes in the set are ");
		for(Box j:s) {
			System.out.println(j);
		}
		sc.close();
	}

}
