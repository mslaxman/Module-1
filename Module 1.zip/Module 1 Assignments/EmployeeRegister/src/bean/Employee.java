package bean;
/**
 * @author Laxman
 */
public class Employee {

	String firstName;
	String lastName;
	long mobile;
	String email;
	String Address;
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public long getMobile() {
		return mobile;
	}
	public String getEmail() {
		return email;
	}
	public String getAddress() {
		return Address;
	}
	public Employee(String firstName, String lastName, long mobile, String email, String address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobile = mobile;
		this.email = email;
		Address = address;
	}
	
	
}
