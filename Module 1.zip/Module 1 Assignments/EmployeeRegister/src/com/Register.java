package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import bean.Employee;
/**
 * @author Laxman
 */
public class Register {

	public static void main(String[] args) {
		
		System.out.println("Enter number of empolyees");
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();

		List<Employee> l=new ArrayList<Employee>();
		
		do {
			System.out.println("Enter First Name: ");
			String fn=sc.next();
			System.out.println("Enter Last Name: ");
			String ln=sc.next();
			System.out.println("Enter Mobile Number: ");
			long m=sc.nextLong();
			System.out.println("Enter email address: ");
			String e1=sc.next();
			System.out.println("Enter Address: ");
			String a=sc.next();
			l.add(new Employee(fn, ln, m, e1, a));
			n--;
			
		}while(n>0);
		Collections.sort(l, (a,b)->a.getFirstName().compareTo(b.getFirstName()));
		
		System.out.println("First Name\tLast Name\tMobile Number\tEmail ID\tAddress");
		
		for(Employee j:l) {
			System.out.println(j.getFirstName()+"\t\t"+j.getLastName()+"\t\t"+j.getMobile()+"\t\t"+j.getEmail()+"\t\t"+j.getAddress());
		}
		sc.close();
	}

}
