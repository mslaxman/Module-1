package com;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 * @author Laxman
 */
public class SList {

	static int ch;
	List<String> l=new ArrayList<String>();
	public void add(String s) {
		l.add(s);
		System.out.println(s+" inserted successfully.");
	}
	public void search(String s) {
		if(l.contains(s)) {
			System.out.println("String found");
		}
		else {
			System.out.println("String not found");
		}
	}
	public void delete(String s) {
		l.remove(s);
		System.out.println(s+" removed from list.");
	}
	public void display() {
		System.out.println("The list is: "+l);
	}
	
	public static void main(String[] args) {
		
		String a="";
		Scanner sc=new Scanner(System.in);
		SList s=new SList();
		do {
			System.out.println("1. Insert");
			System.out.println("2. Search");
			System.out.println("3. Delete");
			System.out.println("4. Display");
			System.out.println("5. Exit");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Enter the item to be inserted: ");
				a=sc.next();
				s.add(a);
				break;
			case 2:
				System.out.println("Enter the item to search: ");
				a=sc.next();
				s.search(a);
				break;
			case 3:
				System.out.println("Enter item to be deleted: ");
				a=sc.next();
				s.delete(a);
				break;
			case 4:
				s.display();
				break;
			case 5:
				System.out.println("Thank you..!!");
				sc.close();
				return;
			}
		}while(true);
		
	}

}
