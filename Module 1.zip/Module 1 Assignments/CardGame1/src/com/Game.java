package com;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import bean.Card;
/**
 * @author Laxman
 */
public class Game {

	
	public static void main(String[] args) {
		int flag=0;
		Set<Card> s = new HashSet<Card>();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int i=0;
		while(flag==0) {
			System.out.println("Enter a card: ");
			String c=sc.next();
			int n=sc.nextInt();
			s.add(new Card(c,n));
			i++;
			if(s.size()==4) {
				flag++;
				System.out.println("Four symbols gathered in "+i+" cards.");
				System.out.println("Cards in set are: ");
				for(Card j:s) {
					System.out.println(j);
				}
				return;
			}
		}
		sc.close();
	}

}
