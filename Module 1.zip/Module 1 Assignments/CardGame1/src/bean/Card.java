package bean;
/**
 * @author Laxman
 */
public class Card {

	String s;
	int n;
	public String getS() {
		return s;
	}
	public int getN() {
		return n;
	}
	public Card(String s, int n) {
		super();
		this.s = s;
		this.n = n;
	}
	
	@Override
	public int hashCode() {
		return 1;
	}
	
	@Override
	public String toString() {
		return s+" "+n;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this.getS().equals(((Card)obj).getS())){
			return true;
		}
		else
			return false;
		
	}
	
}
